#!/bin/bash
# CS 6250 Spring 2023- SDN Firewall Project with POX
# build hackers-44

# This file will start the Mininet topology.  IF you see an error stating 
# Unable to Contact Remote Controller, then you have an issue with your implementation
# in sdn-firewall.py.

sudo python sdn-topology.py