sudo mn -c
sudo killall python
sudo killall pox
